from flask import Flask, redirect, url_for, request
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from flask_cors import CORS
from flask_mail import Mail
from flask_migrate import Migrate
from flask_seeder import FlaskSeeder
from apifairy import APIFairy

import config

db = SQLAlchemy()
migrate = Migrate()
ma = Marshmallow()
mail = Mail()
apifairy = APIFairy()
seeder = FlaskSeeder()

def create_app(config_class):
    app = Flask(__name__)
    app.config.from_object(config_class)
    if app.config['USE_CORS']:  # pragma: no branch
        CORS(app, support_credentials=True)
    db.init_app(app)
    ma.init_app(app)
    
    mail.init_app(app)
    apifairy.init_app(app)
    seeder.init_app(app, db)
    migrate.init_app(app, db)

    # blueprints
    from api.errors import errors
    app.register_blueprint(errors)
    from api.services.auth.routes import tokens
    app.register_blueprint(tokens, url_prefix='/v1/auth')
    from api.services.users.routes import users
    app.register_blueprint(users, url_prefix='/v1/users')
    from api.services.portfolio.routes import portfolio
    app.register_blueprint(portfolio, url_prefix='/v1/portfolio')
    from api.services.jobs.routes import jobs
    app.register_blueprint(jobs, url_prefix='/v1/jobs')
    from api.services.country.routes import country
    app.register_blueprint(country, url_prefix='/v1/countries')

    @app.route('/')
    def index():  # pragma: no cover
        return redirect(url_for('apifairy.docs'))

    @app.after_request
    def after_request(response):
        # Werkzeug sometimes does not flush the request body so we do it here
        request.get_data()
        return response

    return app