<?php

namespace Modules\Job\database\seeders;

use Illuminate\Database\Seeder;

class JobDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
