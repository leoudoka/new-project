<?php

namespace Modules\Employer\database\seeders;

use Illuminate\Database\Seeder;

class EmployerDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
