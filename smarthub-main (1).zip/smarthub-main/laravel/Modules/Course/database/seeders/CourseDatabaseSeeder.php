<?php

namespace Modules\Course\database\seeders;

use Illuminate\Database\Seeder;

class CourseDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
